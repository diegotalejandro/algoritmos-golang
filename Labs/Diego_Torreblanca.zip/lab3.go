package main
import(
  "fmt"
  "io/ioutil"
  "log"
  "strings"
)
type node struct {
	key   int
	value string
	next  *node
}

type table struct {
	array []*node
}

func New(n int) *table {
	return &table{array: make([]*node, n)}
}

func hash(v, n int) int {
	return (v * 1240559) % n
}

func (t *table) insert(key int, value string) {
	h := hash(key, len(t.array))
	t.array[h] = &node{
		key:   key,
		value: value,
		next:  t.array[h],
	}
}

func (t *table) search(key int) (string, bool) {
	h := hash(key, len(t.array))
	aux := t.array[h]
	for aux != nil {
		if aux.key == key {
			return aux.value, true
		}
		aux = aux.next
	}
	return "", false
}

func ReadFile(Directorio string) *table{
  files, err := ioutil.ReadDir(Directorio)
	if err != nil {
		log.Fatal(err)
	}
	blogs:=New(600)
  i:=0
	for _, file := range files {
		blogs.insert(i, file.Name())
    i++
 }
 return blogs
}
func Repeticion(n *table,directorio string,edad int){

for i:=0;i< len(n.array);i++{
  nombre:=n.array[i].value
  x, _ := ioutil.ReadFile(directorio + "/" + nombre)
  aux:=string(x)
  aux = strings.Replace(aux, ".", " ", -1)
  aux = strings.Replace(aux, "…", " ", -1)
  aux = strings.Replace(aux, ",", " ", -1)
  aux = strings.Replace(aux, ":", " ", -1)
  aux = strings.Replace(aux, ";", " ", -1)
  aux = strings.Replace(aux, "!", " ", -1)
  aux = strings.Replace(aux, "¡", " ", -1)
  aux = strings.Replace(aux, "?", " ", -1)
  aux = strings.Replace(aux, "¿", " ", -1)
  aux = strings.Replace(aux, "(", " ", -1)
  aux = strings.Replace(aux, ")", " ", -1)
  aux = strings.Replace(aux, "[", " ", -1)
  aux = strings.Replace(aux, "]", " ", -1)
  aux = strings.Replace(aux, "/", " ", -1)
  aux = strings.Replace(aux, "*", " ", -1)
  aux = strings.Replace(aux, "-", " ", -1)
  aux = strings.Replace(aux, "\"", " ", -1)
  aux = strings.Replace(aux, "{", " ", -1)
  aux = strings.Replace(aux, "}", " ", -1)
  aux = strings.Replace(aux, "_", " ", -1)
  aux = strings.Replace(aux, "+", " ", -1)
  aux = strings.Replace(aux, "<", " ", -1)
  aux = strings.Replace(aux, ">", " ", -1)
  aux = strings.Replace(aux, "@", " ", -1)
  aux = strings.Replace(aux, "#", " ", -1)
  aux = strings.Replace(aux, "=", " ", -1)
  aux = strings.Replace(aux, "$", " ", -1)
  aux = strings.Replace(aux, "%", " ", -1)
  aux = strings.Replace(aux, "~", " ", -1)
  aux = strings.Replace(aux, "'`'", " ", -1)
  aux = strings.Replace(aux, "' ", " ", -1)
  aux = strings.Replace(aux, " '", " ", -1)
  aux = strings.Replace(aux, " ‘", " ", -1)
  aux = strings.Replace(aux, "‘ ", " ", -1)
  aux = strings.Replace(aux, "’ ", " ", -1)
  aux = strings.Replace(aux, " ’", " ", -1)
  aux = strings.Replace(aux, "“ ", " ", -1)
  aux = strings.Replace(aux, " “", " ", -1)
  aux = strings.Replace(aux, "” ", " ", -1)
  aux = strings.Replace(aux, " ”", " ", -1)
  aux = strings.Replace(aux, "�", "", -1)
  aux = strings.ToLower(aux)
  arraux:=strings.Fields(aux)
  switch {
  case edad==1:
  RepeticionEdad1(arraux)
case edad==2:
  RepeticionEdad2(arraux)
case edad==3:
  RepeticionEdad3(arraux)
}
 }
}
var m1 map[string]int
var m2 map[string]int
var m3 map[string]int
func RepeticionEdad1(arr []string){
var m map[string]int
for _, item:= range arr {
  m[item]+=1
 }
}
func RepeticionEdad2(arr []string){
for _, item:= range arr {
  m2[item]+=1
 }
}
func RepeticionEdad3(arr []string){
for _, item:= range arr {
  m3[item]+=1
 }
}
func separar(n *table) (*table,*table,*table) {
rango1:=New(300)
rango2:=New(300)
rango3:=New(300)
	for i := 0; i < len(n.array); i++ {
		comparacion := strings.Split(n.array[i].value, ".")
		if comparacion[2] >= "13" && comparacion[2] <= "17" {
			rango1.insert(i, n.array[i].value)
		}
		if comparacion[2] >= "23" && comparacion[2] <= "27" {
			rango2.insert(i, n.array[i].value)
		}
		if comparacion[2] >= "33" && comparacion[2] <= "47" {
			rango3.insert(i, n.array[i].value)
		}
	}
	return rango1, rango2, rango3
}


func main(){
  var directorio string = "./sampled"
	blogs:= ReadFile(directorio)
  rango1,rango2,rango3:=separar(blogs)
Repeticion(rango1, directorio,1)
Repeticion(rango2, directorio,2)
Repeticion(rango3, directorio,3)
//fmt.Println(m1["i"],m2["i"],m3["i"])
}
